﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace AssignmentsAtanga.Migrations.Country
{
    public partial class Olympics : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Categories",
                columns: table => new
                {
                    CategoryId = table.Column<string>(nullable: false),
                    Name = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Categories", x => x.CategoryId);
                });

            migrationBuilder.CreateTable(
                name: "Games",
                columns: table => new
                {
                    GameId = table.Column<string>(nullable: false),
                    Name = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Games", x => x.GameId);
                });

            migrationBuilder.CreateTable(
                name: "Countries",
                columns: table => new
                {
                    CountryId = table.Column<string>(nullable: false),
                    Name = table.Column<string>(maxLength: 50, nullable: false),
                    GameId = table.Column<string>(nullable: false),
                    CategoryId = table.Column<string>(nullable: false),
                    photopath = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Countries", x => x.CountryId);
                    table.ForeignKey(
                        name: "FK_Countries_Categories_CategoryId",
                        column: x => x.CategoryId,
                        principalTable: "Categories",
                        principalColumn: "CategoryId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Countries_Games_GameId",
                        column: x => x.GameId,
                        principalTable: "Games",
                        principalColumn: "GameId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Categories",
                columns: new[] { "CategoryId", "Name" },
                values: new object[,]
                {
                    { "indoor", "Indoor" },
                    { "outdoor", "Outdoor" }
                });

            migrationBuilder.InsertData(
                table: "Games",
                columns: new[] { "GameId", "Name" },
                values: new object[,]
                {
                    { "winter", "Winter Olympics" },
                    { "Summer", "Summer Olympics" },
                    { "Para", "Paralympics" },
                    { "Youth", "Youth Olympic Games" }
                });

            migrationBuilder.InsertData(
                table: "Countries",
                columns: new[] { "CountryId", "CategoryId", "GameId", "Name", "photopath" },
                values: new object[,]
                {
                    { "can", "indoor", "Winter", "Canada", "canada-flag.png" },
                    { "fin", "outdoor", "Youth", "Finland", "Finland-flag.png" },
                    { "rus", "indoor", "Youth", "Russia", "Russia-flag.png" },
                    { "cyp", "indoor", "Youth", "Cyprus", "Cyprus-flag.png" },
                    { "fra", "indoor", "Youth", "France", "France-flag.png" },
                    { "zim", "outdoor", "Para", "Zimbabwe", "Zimbabwe-flag.png" },
                    { "pak", "outdoor", "Para", "Pakistan", "Pakistan-flag.png" },
                    { "aus", "outdoor", "Para", "Austria", "Austria-flag.png" },
                    { "ukr", "indoor", "Para", "Ukraine", "Ukraine-flag.png" },
                    { "uru", "indoor", "Para", "Uruguay", "Uruguay-flag.png" },
                    { "thai", "indoor", "Para", "Thailand", "Thailand-flag.png" },
                    { "usa", "outdoor", "Summer", "USA", "USA-flag.png" },
                    { "neth", "outdoor", "Summer", "Netherlands", "Netherlands-flag.png" },
                    { "bra", "outdoor", "Summer", "Brazil", "Brazil-flag.png" },
                    { "mex", "indoor", "Summer", "Mexico", "Mexico-flag.png" },
                    { "jap", "outdoor", "Winter", "Japan", "Japan-flag.png" },
                    { "ita", "outdoor", "Winter", "Italy", "Italy-flag.png" },
                    { "jam", "outdoor", "Winter", "Jamaica", "Jamaica-flag.png" },
                    { "Chi", "indoor", "Summer ", "China", "China-flag.png" },
                    { "ger", "indoor", "Summer ", "Germany", "Germany-flag.png" },
                    { "gb", "indoor", "Winter", "Great Britain", "Great-Britain-flag.png" },
                    { "Swe", "indoor", "Winter", "Sweden", "Sweden-flag.png" },
                    { "slov", "outdoor", "Youth", "Slovakia", "Slovakia-flag.png" },
                    { "port", "outdoor", "Youth", "Portugal", "Portugal-flag.png" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Countries_CategoryId",
                table: "Countries",
                column: "CategoryId");

            migrationBuilder.CreateIndex(
                name: "IX_Countries_GameId",
                table: "Countries",
                column: "GameId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Countries");

            migrationBuilder.DropTable(
                name: "Categories");

            migrationBuilder.DropTable(
                name: "Games");
        }
    }
}
