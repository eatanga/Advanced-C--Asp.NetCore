﻿using AssignmentsAtanga.Areas.Olympic.Models;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace AssignmentsAtanga.Areas.Olympic.Controllers
{
    [Area("Olympic")]
    public class CountryController : Controller
    {
        private CountryContext Context { get; set; }
        public CountryController(CountryContext ctx)
        {
            Context = ctx;
        }

       /* public IActionResult index()
        {
            return View(Context.Countries.ToList());
        }

        [HttpGet]
        public IActionResult Add()
        {
            ViewBag.Action = "Add";
            return View("Edit", new Country());
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            ViewBag.Action = "Edit";
            var country = Context.Countries.Find(id);
            return View(country);
        }

        [HttpPost]
        public IActionResult Edit(Country country)
        {
            if (ModelState.IsValid)
            {
                if (country.CountryId == 0)

                    Context.Countries.Add(country);
                else
                    Context.Countries.Update(country);
                Context.SaveChanges();
                return RedirectToAction("Index", "Home");
            }
            else
            {
                ViewBag.Action = (country.CountryId == 0) ? "Add" : "Edit";
                return View(country);
            }
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            var country = Context.Countries.Find(id);
            return View(country);
        }

        [HttpPost]
        public IActionResult Delete(Country country)
        {
            Context.Countries.Remove(country);
            Context.SaveChanges();
            return RedirectToAction("Index", "Home");
        }

        [HttpGet]
        public IActionResult Details(int id)
        {
            var country = Context.Countries.Find(id);
            return View(country);
        }

        /*[HttpGet]
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new StatusCodeResult(400);
            }
            Country country = Context.Countries.Find(id);
            if (country == null)
            {
                return StatusCode(404);
            }
            return View(country);
        }*/
    }
}
