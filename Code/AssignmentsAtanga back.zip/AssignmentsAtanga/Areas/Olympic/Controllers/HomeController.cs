﻿using AssignmentsAtanga.Areas.Olympic.Models;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace AssignmentsAtanga.Areas.Olympic.Controllers
{
    [Area("Olympic")]
    public class HomeController : Controller
    {
        private CountryContext context;

        public HomeController(CountryContext ctx)
        {
            context = ctx;
        }
        public ViewResult Index(string activeGame = "all", string activeCat = "all")
        {
            var model = new CountryListViewModel
            {
                ActiveGame = activeGame,
                ActiveCat = activeCat,
                Games = context.Games.ToList(),
                Categories = context.Categories.ToList()
            };

            //get countries - filter by game and category
            IQueryable<Country> query = context.Countries;
            if (activeGame != "all")
                query = query.Where(t => t.Game.GameId.ToLower() == activeGame.ToLower());
            if (activeCat != "all")
                query = query.Where(t => t.Category.CategoryId.ToLower() == activeCat.ToLower());
            model.Countries = query.ToList();
            return View(model);

        }
    }
}
