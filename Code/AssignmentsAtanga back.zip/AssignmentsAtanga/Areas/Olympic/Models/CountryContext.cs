﻿using Microsoft.EntityFrameworkCore;

namespace AssignmentsAtanga.Areas.Olympic.Models
{
    public class CountryContext : DbContext
    {
        public CountryContext(DbContextOptions<CountryContext> options) : base(options)
        {

        }
        public DbSet<Country> Countries { get; set; }
        public DbSet<Game> Games { get; set; }
        public DbSet<Category> Categories { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Category>().HasData(
                new Category { CategoryId ="indoor", Name="Indoor"},
                new Category { CategoryId = "outdoor", Name ="Outdoor"}
                );

            modelBuilder.Entity<Game>().HasData(
                new Game { GameId = "winter", Name = "Winter Olympics" },
                new Game { GameId = "Summer", Name = "Summer Olympics" },
                new Game { GameId = "Para", Name = "Paralympics" },
                new Game { GameId = "Youth", Name = "Youth Olympic Games" }
                );

            modelBuilder.Entity<Country>().HasData(
                    new  { CountryId = "can", Name = "Canada", GameId = "Winter", CategoryId = "indoor", photopath = "Canada-flag.png" },
                    new  { CountryId = "Swe", Name = "Sweden", GameId = "Winter", CategoryId = "indoor", photopath = "Sweden-flag.png" },
                    new  { CountryId = "gb", Name = "Great Britain", GameId = "Winter", CategoryId = "indoor", photopath = "Great-Britain-flag.png" },
                    new  { CountryId = "jam", Name = "Jamaica", GameId = "Winter", CategoryId = "outdoor", photopath = "Jamaica-flag.png" },
                    new  { CountryId = "ita", Name = "Italy", GameId = "Winter", CategoryId = "outdoor", photopath = "Italy-flag.png" },
                    new  { CountryId = "jap", Name = "Japan", GameId = "Winter", CategoryId = "outdoor", photopath = "Japan-flag.png" },
                    new  { CountryId = "ger", Name = "Germany", GameId = "Summer ", CategoryId = "indoor", photopath = "Germany-flag.png" },
                    new  { CountryId = "Chi", Name = "China", GameId = "Summer ", CategoryId = "indoor", photopath = "China-flag.png" },
                    new  { CountryId = "mex", Name = "Mexico", GameId = "Summer", CategoryId = "indoor", photopath = "Mexico-flag.png" },
                    new  { CountryId = "bra", Name = "Brazil", GameId = "Summer", CategoryId = "outdoor", photopath = "Brazil-flag.png" },
                    new  { CountryId = "neth", Name = "Netherlands", GameId = "Summer", CategoryId = "outdoor", photopath = "Netherlands-flag.png" },
                    new  { CountryId = "usa", Name = "USA", GameId = "Summer", CategoryId = "outdoor", photopath = "USA-flag.png" },
                    new  { CountryId = "thai", Name = "Thailand", GameId = "Para", CategoryId = "indoor", photopath = "Thailand-flag.png" },
                    new  { CountryId = "uru", Name = "Uruguay", GameId = "Para", CategoryId = "indoor", photopath = "Uruguay-flag.png" },
                    new  { CountryId = "ukr", Name = "Ukraine", GameId = "Para", CategoryId = "indoor", photopath = "Ukraine-flag.png" },
                    new  { CountryId = "aus", Name = "Austria", GameId = "Para", CategoryId = "outdoor", photopath = "Austria-flag.png" },
                    new  { CountryId = "pak", Name = "Pakistan", GameId = "Para", CategoryId = "outdoor", photopath = "Pakistan-flag.png" },
                    new  { CountryId = "zim", Name = "Zimbabwe", GameId = "Para", CategoryId = "outdoor", photopath = "Zimbabwe-flag.png" },
                    new  { CountryId = "fra", Name = "France", GameId = "Youth", CategoryId = "indoor", photopath = "France-flag.png" },
                    new  { CountryId = "cyp", Name = "Cyprus", GameId = "Youth", CategoryId = "indoor", photopath = "Cyprus-flag.png" },
                    new  { CountryId = "rus", Name = "Russia", GameId = "Youth", CategoryId = "indoor", photopath = "Russia-flag.png" },
                    new  { CountryId = "fin", Name = "Finland", GameId = "Youth", CategoryId = "outdoor", photopath = "Finland-flag.png" },
                    new  { CountryId = "slov", Name = "Slovakia", GameId = "Youth", CategoryId = "outdoor", photopath = "Slovakia-flag.png" },
                    new  { CountryId = "port", Name = "Portugal", GameId = "Youth", CategoryId = "outdoor", photopath = "Portugal-flag.png" });
        }
    }
}
