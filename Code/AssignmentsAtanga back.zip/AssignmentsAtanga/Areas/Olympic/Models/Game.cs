﻿namespace AssignmentsAtanga.Areas.Olympic.Models
{
    public class Game
    {
        public string GameId { get; set; }
        public string Name { get; set; }
    }
}
