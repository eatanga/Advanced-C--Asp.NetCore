﻿using System;
using AssignmentsAtanga.Areas.Identity.Data;
using AssignmentsAtanga.Data;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

[assembly: HostingStartup(typeof(AssignmentsAtanga.Areas.Identity.IdentityHostingStartup))]
namespace AssignmentsAtanga.Areas.Identity
{
    public class IdentityHostingStartup : IHostingStartup
    {
        public void Configure(IWebHostBuilder builder)
        {
            builder.ConfigureServices((context, services) => {
                services.AddDbContext<AssignDbContext>(options =>
                    options.UseSqlServer(
                        context.Configuration.GetConnectionString("AssignDbContextConnection")));

                services.AddDefaultIdentity<ApplicationUser>(options => options.SignIn.RequireConfirmedAccount = true)
                    .AddEntityFrameworkStores<AssignDbContext>();
            });
        }
    }
}