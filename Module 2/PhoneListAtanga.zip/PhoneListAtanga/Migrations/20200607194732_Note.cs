﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace PhoneListAtanga.Migrations
{
    public partial class Note : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
