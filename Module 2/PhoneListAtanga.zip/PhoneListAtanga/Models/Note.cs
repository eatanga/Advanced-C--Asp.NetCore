﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PhoneListAtanga.Models
{
    public class Note
    {
        public string NoteId { get; set; }
        public string Name { get; set; }
    }
}
